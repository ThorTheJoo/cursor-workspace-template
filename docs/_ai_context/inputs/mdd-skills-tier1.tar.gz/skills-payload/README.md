---
name: mdd-skills-framework
description: "Anthropic Agent Skills-compatible framework extracted from the MDD (Markdown-Driven Development) methodology. Contains 9 portable methodology skills and 5 domain-specific BSS skills."
metadata:
  author: mdd-framework
  version: "1.0.0"
  spec: "agentskills.io v1.0"
  extracted_from: "BSS Document Pipeline (72+ phases)"
---

# MDD Skills Framework

A collection of 14 skills packaged to the [Anthropic Agent Skills specification](https://agentskills.io/specification).
Each skill is self-contained in its own folder with a `SKILL.md` file containing instructions and metadata.

## Tier 1: Portable Skills (Generic MDD Methodology)

These skills work in **any** workspace. They encode the Markdown-Driven Development methodology.

| Skill | Purpose | Key Innovation |
|-------|---------|---------------|
| [mdd-workflow](mdd-workflow/) | Core MDD: P-R-I-L workflow, authority hierarchy, governance | Constitutional truth precedence |
| [plan-generation](plan-generation/) | Self-contained plan writing with quality gates | "Zero prior context" principle |
| [phase-execution](phase-execution/) | Multi-phase execution with validation gates | Context-independent handoffs |
| [data-verification](data-verification/) | Verify data schemas before writing parsing code | Silent failure prevention |
| [context-loading](context-loading/) | Efficient AI context loading via manifests | Sniper mode: manifest-first |
| [knowledge-repo](knowledge-repo/) | Canonical knowledge management with governance | Staging → promotion → versioning |
| [backlog-management](backlog-management/) | Prioritized backlog with aging enforcement | P0 can't defer; P1 escalates after 2 phases |
| [work-logging](work-logging/) | Structured work logging with lessons learned | Regression risk classification |
| [prompt-optimization](prompt-optimization/) | Prompt, plan, and workflow optimization | Progressive disclosure budgeting |

## Tier 2: Domain Skills (BSS/Telecom-Specific)

These skills encode BSS transformation domain expertise. They reference files in `docs/_ai_context/knowledge/`.

| Skill | Purpose |
|-------|---------|
| [bss-domain-expert](bss-domain-expert/) | BSS/telecom domain persona (TM Forum, ArchiMate, pipeline) |
| [archimate-modeling](archimate-modeling/) | ArchiMate 3.2 model generation from documentation |
| [confluence-extraction](confluence-extraction/) | Confluence content extraction and indexing |
| [e2e-document-generation](e2e-document-generation/) | End-to-end use case document generation |
| [correlation-scoring](correlation-scoring/) | Document correlation scoring engine |

## Installation

### In This Workspace
Skills are already installed at `.cursor/skills/`. They are automatically discovered by Cursor.

### In a New Workspace
Copy the `.cursor/skills/` folder to your target workspace root. For portable skills only, copy the 9 Tier 1 folders. See `SKILLS_WORKSPACE_COPY_PROMPT.md` in `docs/_ai_context/prompts/` for a complete agent kickoff prompt.

## Compatibility

- **Cursor**: Skills in `.cursor/skills/` are auto-discovered
- **Claude Code**: Copy to `.claude/skills/` for Claude Code compatibility
- **Claude.ai**: Upload individual SKILL.md files as custom skills
- **Claude API**: Use the Skills API with skill folder paths

## Spec Compliance

All skills follow the [Agent Skills Specification](https://agentskills.io/specification):
- YAML frontmatter with `name` and `description`
- Directory name matches `name` field
- SKILL.md < 500 lines; detailed content in `references/`
- Progressive disclosure: Discovery → Activation → Execution
