---
document_type: STATE
status: ACTIVE
version: "1.0.0"
generated: "2026-03-30"
---

# Skills Index

Machine-readable index of all skills in this workspace.

## Registry

| # | Name | Tier | Status | Phase Created | SKILL.md Lines | Files |
|---|------|------|--------|--------------|----------------|-------|
| 1 | mdd-workflow | portable | COMPLETE | SK-2 | 190 | 8 |
| 2 | plan-generation | portable | COMPLETE | SK-2 | 137 | 5 |
| 3 | phase-execution | portable | COMPLETE | SK-2 | 153 | 9 |
| 4 | data-verification | portable | COMPLETE | SK-3 | 136 | 5 |
| 5 | context-loading | portable | COMPLETE | SK-3 | 160 | 4 |
| 6 | knowledge-repo | portable | COMPLETE | SK-3 | 265 | 9 |
| 7 | backlog-management | portable | COMPLETE | SK-4 | 128 | 2 |
| 8 | work-logging | portable | COMPLETE | SK-4 | 128 | 3 |
| 9 | prompt-optimization | portable | COMPLETE | SK-4 | 180 | 3 |
| 10 | bss-domain-expert | domain | COMPLETE | SK-5 | 110 | 5 |
| 11 | archimate-modeling | domain | COMPLETE | SK-5 | 116 | 6 |
| 12 | confluence-extraction | domain | COMPLETE | SK-5 | 170 | 3 |
| 13 | e2e-document-generation | domain | COMPLETE | SK-5 | 147 | 5 |
| 14 | correlation-scoring | domain | COMPLETE | SK-5 | 104 | 5 |

**Totals:** 14 skills, 72 files, 2,124 SKILL.md lines

## Validation (2026-03-30)

| Check | Result |
|-------|--------|
| All SKILL.md files exist | PASS (14/14) |
| All names match directories | PASS (14/14) |
| All descriptions 1-1024 chars | PASS (14/14) |
| All SKILL.md < 500 lines | PASS (max: 265) |
| All reference pointers resolve | PASS (0 broken) |
| No BSS contamination in Tier 1 | PASS (0 hits) |
| Discovery token budget < 1500 | PASS (~1474) |

## Discovery Budget

| Level | Tokens | What's Loaded |
|-------|--------|---------------|
| Discovery | ~1474 | All 14 name + description fields |
| Activation | ~2,000-4,000 per skill | Full SKILL.md body for triggered skill |
| Execution | As-needed | references/, assets/, scripts/ files |

## Dependency Map

Portable skills (1-9) have NO inter-skill dependencies.
Domain skills (10-14) reference `docs/_ai_context/knowledge/` files.
